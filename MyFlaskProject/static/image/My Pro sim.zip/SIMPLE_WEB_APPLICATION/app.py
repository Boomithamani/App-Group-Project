
import re

import bcrypt
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from wtforms import Form, StringField, PasswordField, validators, ValidationError


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # CHANGE THIS!
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class Userinfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)  # Admin flag (True for admin users)
    is_seller = db.Column(db.Boolean, default=False)  # Seller flag (True for seller users)

    def set_password(self, password):
        salt = bcrypt.gensalt()
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash)

    def __repr__(self):
        return f'<User {self.username}>'

with app.app_context():
    db.create_all()


class Custinfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)  # Admin flag (True for admin users)
    is_seller = db.Column(db.Boolean, default=False)  # Seller flag (True for seller users)

    def set_password(self, password):
        salt = bcrypt.gensalt()
        self.password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)

    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password_hash)

    def __repr__(self):
        return f'<User {self.username}>'


with app.app_context():
    db.create_all()


def validate_username(form, field):
    if not re.match(r'^[a-zA-Z0-9_]+$', field.data):
        raise ValidationError('Username can only contain letters, numbers, and underscores.')

def validate_password(form, field):
    if len(field.data) < 6:
        raise ValidationError("Password must be at least 6 characters long.")
    if not re.search("[a-z]", field.data):
        raise ValidationError("Password must contain at least one lowercase letter.")
    if not re.search("[A-Z]", field.data):
        raise ValidationError("Password must contain at least one uppercase letter.")
    if not re.search("[^a-zA-Z0-9]", field.data):
        raise ValidationError("Password must contain at least one special character.")


class RegistrationForm(Form):
    username = StringField('Username', [
        validators.Length(min=4, max=80),
        validators.DataRequired(),
        validate_username
    ])
    password = PasswordField('Password', [
        validators.DataRequired(),
        validate_password,
        validators.EqualTo('confirm', message='Passwords must match')
    ])
    confirm = PasswordField('Confirm Password')

class LoginForm(Form):
    username = StringField('Username', [validators.DataRequired()])
    password = PasswordField('Password', [validators.DataRequired()])

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        username = form.username.data
        password = form.password.data

        if Userinfo.query.filter_by(username=username).first():
            flash('Username already exists.')
            return redirect(url_for('register'))

        new_user = Userinfo(username=username.lower())
        new_user.set_password(password)
        new_user.set_is_admin = "1"

        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))

    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm(request.form)

    # Fetch only admin users (where is_admin is True) and pass them to the template
    usernames = [user.username for user in Userinfo.query.filter_by(is_admin=True).all()]

    if request.method == 'POST' and form.validate():
        username = form.username.data.strip().lower()
        password = form.password.data

        # Ensure the selected username is an admin user
        user = Userinfo.query.filter(func.lower(Userinfo.username) == username, Userinfo.is_admin == True).first()

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = 'admin' if user.is_admin else 'seller' if user.is_seller else 'customer'

            if user.is_admin:
                return redirect(url_for('admin_dashboard'))
            elif user.is_seller:
                return redirect(url_for('seller_dashboard'))
            else:
                return redirect(url_for('customer_dashboard'))
        else:
            flash('Invalid username or password.')
            return redirect(url_for('login'))

    return render_template('login.html', form=form, usernames=usernames)



@app.route('/customerlogin', methods=['GET', 'POST'])
def customerlogin():
    form = LoginForm(request.form)

    # Fetch only admin users (where is_admin is True) and pass them to the template
    usernames = [user.username for user in Custinfo.query.filter_by(is_admin=True).all()]

    if request.method == 'POST' and form.validate():
        username = form.username.data.strip().lower()
        password = form.password.data

        # Ensure the selected username is an admin user
        user = Custinfo.query.filter(func.lower(Custinfo.username) == username, Custinfo.is_admin == True).first()

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username


            if user.is_admin:
                return redirect(url_for('customer_dashboard'))
            else:
                return redirect(url_for('customer_dashboard'))
        else:
            flash('Invalid username or password.')
            flash('Invalid username or password.')
            return redirect(url_for('customerlogin'))

    return render_template('customerlogin.html', form=form, usernames=usernames)


@app.route('/customerregister', methods=['GET', 'POST'])
def customerregister():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        username = form.username.data
        password = form.password.data

        if Custinfo.query.filter_by(username=username).first():
            flash('Username already exists.')
            return redirect(url_for('register'))

        new_user = Custinfo(username=username.lower())
        new_user.set_password(password)
        new_user.set_is_seller= "True"

        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect(url_for('customerlogin'))

    return render_template('customerregister.html', form=form)

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        flash("Access denied.")
        return redirect(url_for('login'))

    users = Userinfo.query.all()
    return render_template('admin_dashboard.html', users=users)


@app.route('/seller_dashboard')
def seller_dashboard():
    if 'role' not in session or session['role'] != 'seller':
        flash("Access denied.")
        return redirect(url_for('login'))

    return render_template('seller_dashboard.html')


@app.route('/customer_dashboard')
def customer_dashboard():
    users = Custinfo.query.all()
    return render_template('customer_dashboard.html', users=users)


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('is_admin', None)
    return redirect(url_for('index'))




@app.route('/user/delete/<int:id>')
def delete_user(id):
    if 'user_id' not in session or not session.get('is_admin'):
        flash("You are not authorized to perform this action.")
        return redirect(url_for('admin_dashboard'))

    user = Userinfo.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    app.run(debug=True)